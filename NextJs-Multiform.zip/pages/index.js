

import MainForm from './MainForm';

export default () => 
      <div>
        <MainForm/>
      </div>
;
