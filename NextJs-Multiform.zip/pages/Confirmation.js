import React, { Component } from 'react';


class Confirmation extends Component {
  saveAndContinue = (e) => {
    e.preventDefault();
    this.props.nextStep();
  }

  back = (e) => {
    e.preventDefault();
    this.props.prevStep();
  }

  render() {
    const { values: { firstName, lastName, email, age, city, country } } = this.props;

    return (
      <div>
        <h1 className="ui centered">Confirm your Details</h1>
        <p>Click Confirm if the following details have been correctly entered</p>
        <ul>
          <li>First Name: {firstName}</li>
          <li>Last Name: {lastName}</li>
          <li>Email: {email}</li>
          <li>{age} Years</li>
          <li>{city}, {country}</li>
        </ul>

        <button onClick={this.back}>Back</button>
        <button onClick={this.saveAndContinue}>Confirm</button>
      </div>
    )
  }
}

export default Confirmation;